#!/usr/bin/env python3
#Author: HiruNya
#Modified by: 31ank

# HentaiBot v2
from data import LastEntry
from config import Config, HentaiHavenConfig, HAnimeConfig, RedditPornConfig, Section
from src import Discord, HentaiHaven, HAnime, Reddit, RedditPorn


def start():
    config: Config = Config("config.yaml")
    last_entry: LastEntry = LastEntry("./data/last_entry.yaml")
    discord: Discord = Discord(token=config.token)
    hentai_haven = HentaiHaven(
        discord,
        config.hentai_haven,
        last_entry
    )
    hanime = HAnime(
        discord,
        config.hanime,
        last_entry
    )

    reddit = [Reddit(discord, c) for c in config.reddit]
    redditporn = [RedditPorn(discord, c) for c in config.redditporn]
    
    hentai_haven.start()
    hanime.start()
    for r in reddit:
        r.start()
    
    for r in redditporn:
        r.start()

    hentai_haven.join()
    hanime.join()
    last_entry.write()
    for r in reddit:
        r.join()

    for r in redditporn:
        r.join()


if __name__ == "__main__":
    start()
