#UltimateHentaiBot V1.3.7
#Author: 31ank
import discord
from discord.ext import commands
import os
import sys
import time as timet
from datetime import date, time
import datetime
from threading import Timer
from yaml import load, dump
import yaml
import requests

#---start---
bot = commands.Bot(description="HentaiBot", command_prefix="<", pm_help = True) #you can change here the prefix
startup_extensions = ["cogs.updatechannel", "cogs.general", "cogs.admin", "cogs.communities"] #add here the extensions if you want to add one
game = discord.Game("<h for help") #change game here
#---start---

#---Variables---
uptime = timet.time() #starttime of the bot
start_time = timet.time()
#---Variables---

#---load and update---
with open("config.yaml") as file: #load token from config file
        data = load(file)
        token = data["token"]
        linuxuser = data["linuxuser"]
        username = data["user"]

def updatehentai(): #update feed
        t = Timer(1800, updatehentai) #every half hour an update happens
        t.start() #start next timer

        start_time = 1
        start_time_old = start_time

        now = datetime.datetime.now()
        now_time = now.time()
        if now_time >= time(00,00) and now_time <= time(00,30): #check if current time is between
                if linuxuser == False:
                        os.system("python HentaiBot.py")
                else:
                        os.system("python3.6 HentaiBot.py")
                start_time = timet.time()
        elif now_time >= time(4,00) and now_time <= time(4,30):
                if linuxuser == False:
                        os.system("python HentaiBot.py")
                else:
                        os.system("python3.6 HentaiBot.py")
                start_time = timet.time()
        elif now_time >= time(8,00) and now_time <= time(8,30):
                if linuxuser == False:
                        os.system("python HentaiBot.py")
                else:
                        os.system("python3.6 HentaiBot.py")
                start_time = timet.time()
        elif now_time >= time(12,00) and now_time <= time(12,30):
                if linuxuser == False:
                        os.system("python HentaiBot.py")
                else:
                        os.system("python3.6 HentaiBot.py")
                start_time = timet.time()
        elif now_time >= time(16,00) and now_time <= time(16,30):
                if linuxuser == False:
                        os.system("python HentaiBot.py")
                else:
                        os.system("python3.6 HentaiBot.py")
                start_time = timet.time()
        elif now_time >= time(20,00) and now_time <= time(20,30):
                if linuxuser == False:
                        os.system("python HentaiBot.py")
                else:
                        os.system("python3.6 HentaiBot.py")
                start_time = timet.time()

        if start_time != start_time_old: #if start_time has changed
            with open('time_start', 'w') as writer:
                writer.write(str(start_time)) #write start time into file
#---load and update---

#---bot---
@bot.event
async def on_ready(): #terminal message on start
	print('Logged in as ' + bot.user.name + ' (ID:' + str(bot.user.id) + ') | Connected to ' + str(len(bot.guilds)) + ' servers | Connected to ' + str(len(list(bot.get_all_members()))) + ' Users')
	print('--------')
	await bot.change_presence(status=discord.Status.online, activity=game)

@bot.command(brief='Latency of the bot', description='Show the latency of the bot') #ping command
async def ping(ctx):
        await ctx.send(':ping_pong: Pong! ~' + str(round(bot.latency * 1000, 2)) + " ms")

@bot.command(pass_context=True, hidden=True)
async def load_ext(ctx, extension_name : str): #load extension
        if(str(ctx.message.author) == username): #check if user == user in the config file
                try:
                        bot.load_extension(extension_name)
                except (AttributeError, ImportError) as e: #error loading the extension
                        await ctx.send("```py\n{}: {}\n```".format(type(e).__name__, str(e)))
                        return
                await ctx.send("{} loaded".format(extension_name))
        else: #user is not owner
                await ctx.send('You dont look like my onii-chan!')

@bot.command(pass_context=True, hidden=True)
async def unload_ext(ctx, extension_name : str): #unload extension
        if(str(ctx.message.author) == username): #check if user == user in the config file
                try:
                        bot.unload_extension(extension_name)
                        await ctx.send("{} unloaded".format(extension_name))
                except: #error unloading the extension
                        await ctx.send("error unloading")
        else: #user is not owner
                await ctx.send('You dont look like my onii-chan!')

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandOnCooldown):
        await ctx.send('Command is on cooldown') #cooldown message
#---bot---

#---load and update---
for extension in startup_extensions: #load extensions at start
        try:
                bot.load_extension(extension)
        except Exception as e:
                exc = '{}: {}'.format(type(e).__name__, e)
                print('Failed to load extension {}\n{}'.format(extension, exc))

with open('time_up', 'w') as writer: #write uptime into file
        writer.write(str(uptime))
with open('time_start', 'w') as writer: #write start_time into file
        writer.write(str(start_time))
#---load and update---

t = Timer(10, updatehentai) #run the script when the bot starts
t.start() #start the timer


bot.run('{}'.format(token))