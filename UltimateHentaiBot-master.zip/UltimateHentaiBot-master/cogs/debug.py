#UltimateHentaiBot Debug V1.0
import os
from yaml import load, dump
import yaml
import discord
from discord.ext import commands

class Debug():
    def __init__(self, client):
        self.client = client

    @commands.command(pass_context=True)
    async def activ(self, ctx):
        await ctx.send("ACTIV")

    @commands.command(pass_context=True)
    async def force_update(self, ctx, linuxuser = "false"):
        await ctx.send("Forcing update for all channels")
        if linuxuser == "false":
            os.system('python HentaiBot.py')
        else:
            os.system('python3.6 HentaiBot.py')

    @commands.command(pass_context=True)
    async def check(self, ctx, site):
        response = os.system("ping " + site)
        if response == 1:
            await ctx.send("Offline")
        else:
            await ctx.send("Online")

def setup(bot):
    bot.add_cog(Debug(bot))