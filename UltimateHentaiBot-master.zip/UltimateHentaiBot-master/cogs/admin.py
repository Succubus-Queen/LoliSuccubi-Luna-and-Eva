#UltimateHentaiBot Admin V1.1
import os
from yaml import load, dump
import yaml
import discord
from discord.ext import commands

class Admin():
    def __init__(self, client):
        self.client = client

    @commands.command(pass_context=True, brief='Delete [numbers] of messages (Admin only)', description='Delete [numbers] of messages') #delete command
    async def delete(self, ctx, number):
        if ctx.message.author.guild_permissions.administrator:
            try:
                number = int(number) #try to convert the string to a number
            except:
                await ctx.send("You need to enter a number!", delete_after=5)
                return
            if number > 99 or number < 1: #more than 99 messages cannot be deleted!
                await ctx.send("I can only delete messages within a range of 1 - 99", delete_after=5)
            else: #delete messages
                mgs = []
                number = int(number)
                async for x in ctx.history(limit = int(number+1)):
                    mgs.append(x)
                    print(mgs)
                await ctx.message.channel.delete_messages(mgs)
                await ctx.send('Success! This message deletes itself in 3 seconds', delete_after=3)
        else:
            await ctx.send("B-B-B-BAAAKAAAA, you are not allowed to use this command!")

def setup(bot):
    bot.add_cog(Admin(bot))
