#UltimateHentaiBot UpdateChannel V1.3
from yaml import load, dump
import yaml
import discord
from discord.ext import commands

class UpdateChannel():
    def __init__(self, client):
        self.client = client

#---HENTAI Start---
    @commands.cooldown(1, 5, commands.BucketType.channel)
    @commands.command(pass_context=True, brief='Add channel to the hentai update-list', description='Add this channel to the hentai update list(nsfw)(admin only)(bot needs write permission!)') #add to hentai list command
    async def addtohentailist(self, ctx):
        try:
            if ctx.message.channel.is_nsfw():
                if ctx.message.author.guild_permissions.administrator: #does user have admin rights?
                        ad_ch = ctx.message.channel.id #get channel id

                        with open("channels.yaml", encoding='utf-8') as file: #load other channels
                            datachan = load(file)
                        if ad_ch in datachan["channels"]: #channel already in update list
                                await ctx.send('Already in update list')
                        else: #channel not in update list
                                datachan["channels"].append(ad_ch) #add channel

                                with open('channels.yaml', 'w') as writer: #save new file
                                    yaml.dump(datachan, writer)

                                await ctx.send('Added channel')
                                #await ctx.send(ctx.message.author, 'Added channel ' + ad_ch + ' to the hentai update list, dont forget to give me write permissions!') Message causes an error
                else:
                        await ctx.send('You are not allowed to use this command')
            else:
                await ctx.send('This channel does not have an nsfw-tag! Please change the channel settings!')
        except:
            await ctx.send('Looks like an error occured, please try again')

    @commands.cooldown(1, 5, commands.BucketType.channel)
    @commands.command(pass_context=True, brief='Remove channel from the hentai update-list', description='Remove this channel from the hentai update list(admin only)') #remove from hentai list command
    async def removefromhentailist(self, ctx):
        try:
            if ctx.message.author.guild_permissions.administrator: #does user have admin rights?

                    re_ch = ctx.message.channel.id #get channel id

                    with open("channels.yaml", encoding='utf-8') as file: #load other channels
                            datachan = load(file)
                    try:
                            datachan["channels"].remove(re_ch) #remove channel

                            with open('channels.yaml', 'w') as writer: #save new file
                                    yaml.dump(datachan, writer)

                            await ctx.send('Removed channel')
                    except:
                            await ctx.send('An error occured, please contact @31ank4002')
            else:
                    await ctx.send('You are not allowed to use this command')
        except:
            await ctx.send('Looks like an error occured, please try again')

#---Hentai End---
#---PORN Start---
    @commands.cooldown(1, 5, commands.BucketType.channel)
    @commands.command(pass_context=True, brief='Add channel to the porn update-list', description='Add this channel to the porn update list(nsfw)(admin only)(bot needs write permission!)') #add to porn list command
    async def addtopornlist(self, ctx):
        try:
            if ctx.message.channel.is_nsfw():
                if ctx.message.author.guild_permissions.administrator: #does user have admin rights?
                        ad_ch = ctx.message.channel.id

                        with open("channels.yaml", encoding='utf-8') as file:
                            datachan = load(file)
                        if ad_ch in datachan["pornchannels"]: #channel already in update list
                                await ctx.send('Already in update list')
                        else: #channel not in update list
                                datachan["pornchannels"].append(ad_ch)

                                with open('channels.yaml', 'w') as writer:
                                    yaml.dump(datachan, writer)

                                await ctx.send('Added channel')
                                #await ctx.send(ctx.message.author, 'Added channel ' + ad_ch + ' to the porn update list, dont forget to give me write permissions!') Message causes an error
                else:
                        await ctx.send(ctx.message.channel, 'You are not allowed to use this command')
            else:
                await ctx.send('This channel does not have an nsfw-tag! Please change the channel settings!')
        except:
            await ctx.send('Looks like an error occured, please try again')

    @commands.cooldown(1, 5, commands.BucketType.channel)
    @commands.command(pass_context=True, brief='Remove channel from the porn update-list', description='Remove this channel from the porn update-list(admin only)') #remove from porn list command
    async def removefrompornlist(self, ctx):
        try:
            if ctx.message.author.guild_permissions.administrator: #does user have admin rights?

                    re_ch = ctx.message.channel.id

                    with open("channels.yaml", encoding='utf-8') as file:
                            datachan = load(file)
                    try:
                            datachan["pornchannels"].remove(re_ch)

                            with open('channels.yaml', 'w') as writer:
                                    yaml.dump(datachan, writer)

                            await ctx.send('Removed channel')
                    except:
                            await ctx.send('An error occured, maybe the channel is already removed? If there is still a problem please contact @31ank4002')
            else:
                    await ctx.send('You are not allowed to use this command')
        except:
            await ctx.send('Looks like an error occured, please try again')
#---PORN End---

def setup(bot):
    bot.add_cog(UpdateChannel(bot))
