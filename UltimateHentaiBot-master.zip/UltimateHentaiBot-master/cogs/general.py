#UltimateHentaiBot General V1.6
import os
from yaml import load, dump
import yaml
import discord
from discord.ext import commands
import time as timet
import datetime
from requests import get
from json import dumps as jdump

#---Variables---
start_time = 0
start_time_str = "0"
circle = 0
actual_time = 0
timetillnextupdate = 0
uptime = 0
start_time_bot = 0
start_time_bot_str = "0"
#---Variables---

class General():
    def __init__(self, client):
        self.client = client

    @commands.command(pass_context=True, brief='Some infos about the bot', description='Some infos about the bot (user count, server count, etc.)') #info command
    async def info(self, ctx):
        with open("time_up", encoding='utf-8') as file: #load start time of bot
            start_time_bot_str = file.read()
            start_time_bot = float(start_time_bot_str)
        uptime = round((((timet.time() - start_time_bot)/60)/60), 2)
        info = discord.Embed(title='UltimateHentaiBot', description='', color=0xffffff) #create embed for the info field
        #info.set_image(url="https://i.imgur.com/38neHmo.jpg") if you want your bot image in <info command
        info.add_field(name='Author', value='@31ank#4002')
        info.add_field(name='Server count', value=str(len(self.client.guilds))) #server count
        info.add_field(name='User count', value=str(len(list(self.client.get_all_members()))))

        if(start_time_bot != 0): #if there was an error reading the time -> no message
            info.add_field(name='Uptime', value=(str(uptime) + ' hours ')) #time since bot is up
        else:
            info.add_field(name='Uptime', value=('Looks like I cannot calculate this :|'))

        info.add_field(name='Invite - Link', value='https://discordapp.com/oauth2/authorize?client_id=414167057224171520&scope=bot&permissions=232448')
        info.add_field(name='GitHub', value='https://github.com/31ank/UltimateHentaiBot')
        await ctx.send(embed=info)

    @commands.command(brief='Support - Server inivte link', description='Invite - Link for the support server') #support - server invite link
    async def support(self, ctx):
        info = discord.Embed(title='Support Server', description='https://discord.gg/Wmj76Fm', color=0xffffff)
        await ctx.send(embed=info)

    @commands.command(brief='Time till next update', description='Time till the next refresh/update (for hentai and porn list)') #next update command
    async def nextupdate(self, ctx):
        try: #try to get time since last update
            with open("time_start", encoding='utf-8') as file: #read time since last update
                start_time_str = file.read()
            start_time = float(start_time_str)
            actual_time = timet.time()
            circle = 14400 #every 4 hours update -> 4 * 60 * 60
            timetillnextupdate = circle - (actual_time - start_time)
            timetillnextupdate_s = timetillnextupdate #convert time to hours, minutes and seconds
            timetillnextupdate_m = round(timetillnextupdate_s / 60, 2)
            timetillnextupdate_h = round(timetillnextupdate_m / 60, 2)
            if timetillnextupdate_h > 1: #check the time to know what time - format should be used
                await ctx.send('Time till next update: ' + str(timetillnextupdate_h) + ' hours')
            elif timetillnextupdate_m > 1:
                await ctx.send('Time till next update: ' + str(timetillnextupdate_m) + ' minutes')
            elif timetillnextupdate_s > 1:
                await ctx.send('Time till next update: ' + str(timetillnextupdate_s) + ' seconds')
            else: #send error message
                await ctx.send('Looks like an error occured, please send this to @31ank#4002```sta' + str(start_time) + 'cir' + str(circle) + 'act' + str(actual_time) + 'ttu' + str(timetillnextupdate) + '```')
        except: #error while sending the message or calculating the time
            await ctx.send('Looks like an error occured, please send this to @31ank#4002```sta' + str(start_time) + 'cir' + str(circle) + 'act' + str(actual_time) + 'ttu' + str(timetillnextupdate) + '```')

    @commands.command(brief='Invite - Link', description='Get the invite link of the bot') #ping command
    async def invite(self, ctx):
        await ctx.send("Here's the invite link:\nhttps://discordapp.com/oauth2/authorize?client_id=414167057224171520&scope=bot&permissions=232448")

    @commands.command(pass_context=True, brief='New help command', description='The new help command is now using an embed')
    async def h(self, ctx, help = "n"):
        if help == "n":
            info = discord.Embed(title='UltimateHentaiBot Help', description='For a specific command type <help [command]. If this help does not help you, try <help (not <h)', color=0xff0000) #create embed for the info field
            if ctx.message.author.guild_permissions.administrator:
                info.add_field(name='Admin', value="delete [n] - delete n messages\naddtohentailist - add channel to hentai update list\naddtopornlist - add channel to porn update list\nremovefromhentailist - remove channel from hentai list\nremovefrompornlist - remove channel from porn list")
                info.add_field(name='UpdateChannel', value="addtohentailist - add channel to hentai update list (reddit, hentaihaven, hanime)\nremovefromhentailist - remove channel from hentai update list\naddtopornlist - add channel to porn update list (reddit)\nremovefrompornlist - remove channel from porn update list")
            info.add_field(name='Communities', value="neko [tag] - get picture form nekos.life with a specific tag (for all tags write <help neko)\nr [subreddit] [rising/hot/best] - get post of a subreddit\nyandere [tag] - get picture with specific tag from yande.re\nkonachan [tag] - get picture with specific tag from konachan\ndanbooru [tag] - get specific tag from danbooru")
            info.add_field(name='General', value="ping - latency of the bot\ninfo - some infos about the bot\nnextupdate - get time till next update\ninvite - get the invite link")
            await ctx.message.author.send(embed=info)

def setup(bot):
    bot.add_cog(General(bot))
