# UltimateHentaiBot #

### Info:
I'm working on a big update at the moment, so no updates or bug fixes in the next time

### What can it do? ###
Check HentaiHaven.org and/or hanime.tv if a new hentai got released. If a new one got released, the bot sends a msesage to the specific channels. It is also capable of sending the top posts of subreddits.
Everything can be changed in the config.yaml. The bot is set to update every 4 hours, but you can change the <a href="https://github.com/31ank/UltimateHentaiBot/wiki/Setup-guides#change-update-time">time manually in the code</a>.

#### Don't want to host your own bot? Invite this one: ####
<a href="https://discordapp.com/oauth2/authorize?client_id=414167057224171520&scope=bot&permissions=232448">Invite Link</a>

### Commands: ###
Command | Description | Usage
----------------|--------------|-------
`<h` | Get all commands (new help command)(beta) | `h`
`<help` | Get all commands (old help command) | `help`
`<ping` | Response time of the bot | `<ping`
`<info` | Some infos about the bot | `<info`
`<nextupdate` | Time till next update | `<nextupdate`
`<r` | get rising/hot/top post of subreddit | `<r [subreddit] [hot/rising/best]`
`<neko` | get pictures from nekos.life | `<neko [optional tag]`
`<yandere` | get top post of a tag from yande.re | `<yandere [tag]`
`<konachan` | get top post of a tag from konachan.com | `<konachan [tag]`
`<danbooru` | get top post of a tag from konachan.com | `<danbooru [tag]`
`<delete` | delete messages in a channel (admin only) | `<delete [numbers]`
`<addtohentailist` | add channel to hentai-update list (admin only) | `<addtohentailist`
`<addtopornlist` | add to porn update-list (admin only) | `<addtopornlist`
`<removefromhentailist` | remove from hentai update-list (admin only) | `<removefromhentailist`
`<removefrompornlist` | remove from porn update-list (admin only) | `<removefrompornlist`
`<load_ext` | load extension (Owner only) | `<load_ext [extension name]`
`<unload_ext` | unload extension (Owner only) | `<unload_ext [extension name]`

Reddit - Command uses hot if no parameter is given

### Dependencies: ###
- Python 3.6<br>
- feedparser  (For reading the RSS feed)<br>
- yaml  (For reading and writing to the config file)<br>
- requests  (For writing a POST request to Discord)<br>
- nekos.py  (For nekos.life functions)<br>
- json <b>\[Standard Library]</b>  (For writing the information sent to Discord)<br>
- xml <b>\[Standard Library]</b>  (For reading some of the XML text)<br>
- discord.py rewrite version (It's a discord bot)(you need to use the rewrite version of discord.py!)<br>

### Setup: ###
Better guide: <a href="https://github.com/31ank/UltimateHentaiBot/wiki/Setup-guides">LINK</a>
1. Make sure that the dependencies are installed using <b>pip</b> or some other method.<br>
  - to install "feedparser" write ```pip install feedparser```,<br>
  - to install "yaml" write ```pip install pyYAML```,<br>
  - to install "requests" write ```pip install requests```,<br>
  - to install "nekos.py", follow this guide: <a href="https://github.com/Nekos-life/nekos.py">Link</a>,<br>
  - and to install "discord.py" write ```pip install -U git+https://github.com/Rapptz/discord.py@rewrite#egg=discord.py```<br>

2. Configure the config.yaml by:
  - Adding the token which you obtain by creating your bot with Discord. You can get it on the <a href="https://discordapp.com/developers/docs/intro" target="_blank">Discord Dev Page</a>
  - Change how many posts it sends or which subreddits should be checked.

3. Start Bot.py (in commandline ```python Bot.py```(Python 3.6 is required!))
If you get an error with aiohttp, then you also need to install this: ```pip install "yarl<1.2"```

4. Enjoy your bot!

#### Source: ####
HentaiBot by HiruNya (https://github.com/HiruNya/HentaiBot)<br>
https://hentaihaven.org (nsfw)<br>
https://hanime.tv (nsfw)<br>
https://reddit.com/r/hentai (nsfw)<br>
https://reddit.com/r/hentai_irl (nsfw)<br>
https://reddit.com/r/porn (nsfw)<br>
https://yande.re (nsfw)<br>
https://konachan.com (nsfw)<br>
