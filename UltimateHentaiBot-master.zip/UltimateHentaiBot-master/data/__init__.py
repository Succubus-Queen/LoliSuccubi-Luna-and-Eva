from .last_entry import LastEntry
